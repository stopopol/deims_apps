#!/bin/bash

clisos=$1
host=$2
port=$3
url=$4
offering=$5

CONFIG_TEMPLATE="
[getObservation]
offering = $offering
stations = STATIONS_
parameter = PARAMETERS
resultmodel = om:Observation
starttime = 2020-09-14T15:45:19
endtime = 2020-09-15T15:45:19

[connection]
host = $host
port = $port
url  = $url

"

FILE=./cfg.template
if [ -f "$FILE" ]; then
    cfg_template=$(<$FILE)
else 
    cfg_template=$CONFIG_TEMPLATE
fi


while read proc;
do
	b=$(echo $($clisos -h $host -p $port -u $url -s $proc -D))
	for param in ${b//;/ }
	do
	    fn=$proc.$param.cfg
	    echo "create config: $fn"
	    v="${cfg_template/PARAMETERS/$param}"
	    c="${v/STATIONS_/$proc}"
	    echo "$c" > $fn
	done
done