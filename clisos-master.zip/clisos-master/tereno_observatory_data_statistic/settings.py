'''
Created on Sep 27, 2018

@author: sorg
'''
clisos_bases={}

