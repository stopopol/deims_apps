'''
Created on Sep 27, 2018

@author: sorg
'''
import settings
settings.clisos_bases = {"HMGU":["%s -h 146.107.1.84 -p 8089 -u /HMGU_SY_FLAECHE_09_public/sos ",
                                 "%s -h 146.107.1.84 -p 8089 -u /HMGU_SY_WS_03_public/sos ",
                                 "%s -h 146.107.1.84 -p 8089 -u /HMGU_SY_LYSI_01_public/sos "], }
import sosdatalizer

