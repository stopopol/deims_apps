'''
Created on Jan 24, 2017

@author: sorg
'''

"""
usage:
python ~/local/clisos/.py > available.data.csv 2>error
"""

import commands, sys, time
from datetime import datetime, timedelta
from settings import clisos_bases

print >> sys.stderr, "clisos_bases: ",clisos_bases

clisos = "clisos "
        
startDate="2000-01-01"
endDate="2019-01-01"
deltaDays=180

datetimeFormat="%Y-%m-%d"
start=datetime.strptime(startDate,datetimeFormat)
end=datetime.strptime(endDate,datetimeFormat)
delta=timedelta(days=int(deltaDays))

one_minute=timedelta(minutes=1)

ufzSleepTime=1

def myPrint(msg, status=0):
    if status != 0:
        sys.stderr.write(msg)
        
def skipUFZsensorComponents(observatory, proc):
    if observatory=="UFZ":
        t=proc.split(":")
        return t[len(t)-2]!="UFZ"
    return False

def runCliSos(clisos_base, offering, proc, phen, srs="EPSG:4326"):
    begin=start
    actual=begin+delta
    countDataPoints=0
    firstDs="unkown"
    lastDs="unkown"
    firstTime=True
    while begin<end:
        print >> sys.stderr, begin.isoformat()," - ",actual.isoformat()
        cmd = "%s -k -r %s -o %s -d %s -b %s -e %s,%s -G " % (clisos_base,srs, offering, proc, phen, begin.isoformat(), actual.isoformat())
        print >> sys.stderr, cmd
        status, out = commands.getstatusoutput(cmd)
        if status == 0:
            if out.find("no data available")<0:
                data = out.split("\n")
                data = sorted(data)
                data0 = data[0]
                dataN = data[len(data) - 1]
                d0 = data0.split(",")
                dN = dataN.split(",")
                countDataPoints=countDataPoints+len(data)
                if firstTime:
                    firstTime=False
                    firstDs=d0[0]
                lastDs=dN[0]
            else:
                print >> sys.stderr,"no data available"
        else:
            myPrint(out, status)
        begin=actual-one_minute
        actual=actual+delta
        if observatory=='UFZ':
            myPrint("sleeping %s s"%ufzSleepTime,1)
            time.sleep(ufzSleepTime)
    print observatory,";", proc, ";", phen, ";", firstDs, ";", lastDs, ";", countDataPoints

for observatory in clisos_bases.keys():
    #ufz_workaround=""
    srs="EPSG:4326"
    if observatory=="UFZ":
        srs="EPSG::4326"
    for sos in clisos_bases[observatory]:
        clisos_base=sos%(clisos,)
        cmd = "%s -O" % (clisos_base)
        myPrint(cmd)
        status, out = commands.getstatusoutput(cmd)
        if status == 0:
            myPrint(out)
            offerings = out.split("\n")
            for offering in offerings:
                cmd = "%s -o %s -S" % (clisos_base, offering)
                myPrint(cmd)
                status, out = commands.getstatusoutput(cmd)
                cmd = "%s -o %s -L" % (clisos_base, offering)
                status2, out2 = commands.getstatusoutput(cmd)
                if status == 0 and status2 == 0:
                    offeringPhens = out2.split("\n")
                    myPrint(out)
                    procs = out.split("\n")
                    for proc in procs:
                        if skipUFZsensorComponents(observatory, proc):
                            continue
                        cmd = "%s -s %s -D" % (clisos_base, proc)
                        myPrint(cmd)
                        status, out = commands.getstatusoutput(cmd)
                        if status == 0:
                            myPrint(out)
                            phens = out.split("\n")
                            alreadyProcessedPhens={}
                            for phen in phens:
                                if not alreadyProcessedPhens.has_key(phen) and phen in offeringPhens:
                                    runCliSos(clisos_base, offering, proc, phen, srs)
                                    alreadyProcessedPhens[phen]=phen
                        else:
                            myPrint(out, status)
                else:
                    myPrint(out, status)
        else:
            myPrint(out, status)
