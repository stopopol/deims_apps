'''
Created on Sep 27, 2018

@author: sorg
'''
import settings
settings.clisos_bases = {"UFZ": ["%s -h sos.ufz.de -p 443 -u /tereno-qsos/service"]}
import sosdatalizer

