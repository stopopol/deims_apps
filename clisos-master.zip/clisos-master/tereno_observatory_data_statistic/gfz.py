'''
Created on Sep 27, 2018

@author: sorg
'''
import settings
settings.clisos_bases={"GFZ": ["%s -h 139.17.3.204 -p 8080 -u /terenodata_public/sos "],}
import sosdatalizer

