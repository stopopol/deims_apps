'''
Created on Sep 27, 2018

@author: sorg
'''
import settings
settings.clisos_bases={"KIT": ["%s -h 195.37.187.130 -p 9653 -u /soilnetfendtdata_all/sos ",
                               "%s -h 195.37.187.130 -p 9653 -u /terenogapdata_all/sos ",
                               "%s -h 195.37.187.130 -p 9653 -u /lysimeterdata_all/sos "],
}
import sosdatalizer
