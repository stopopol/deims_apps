'''
Created on May 31, 2016

@author: sorg
'''


import sys,commands,datetime

lines = sys.stdin.readlines()

clisos="clisos -h %s -u %s -p %s -Y | wc -l"

for line in lines:
    t=eval(line)
    start=datetime.datetime().now()
    status,out=commands.getstatusoutput(line)
    if status!=0:
        print ""