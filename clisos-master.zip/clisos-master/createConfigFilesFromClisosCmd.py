'''
Created on Feb 18, 2015

@author: sorg
'''

test=["-h  ibg3wradar.ibg.kfa-juelich.de -p 8080 -u /eifelrur_quality/sos -b RO_"]
