'''
Created on Feb 13, 2015

@author: sorg
'''

"""
usage:

python getAllStationsOfASos.py INPUT_FILE [PRINT_SML]

INPUT_FILE is list of urls like:

NAME SERVER PATH

here is an example:
echo "samples http://ibg3wradar.ibg.kfa-juelich.de:8080 /samples_public/sos"  > /dev/shm/sos &&  python /home/sorg/development/fzj/workspace.neon/clisos/getAllStationsOfASos.py /dev/shm/sos
"""  

import call_clisos,sys

args=call_clisos.callClisos(sys.argv[1])

printSml=False
if len(sys.argv)>2:
    printSml=True

import commands
clisos="clisos "
a={}
for name in args.keys():
    clisosArgs=args[name]
    cmd=clisos+clisosArgs+" -O"
    status,out=commands.getstatusoutput(cmd)
    a[name]=(clisosArgs,out.split("\n"))

result={}
for k in a.keys():
    offerings=a[k][1]
    clisosArgs=a[k][0]
    for offering in offerings:
        cmd=clisos+clisosArgs+' -o "%s" -S'%(offering,)
#        if k=="GFZ":
#            print cmd
        status,out=commands.getstatusoutput(cmd)
        stations=out.split("\n")
        if result.has_key(k):
            result[k][0].extend(stations)
        else:
            result[k]=[stations,clisosArgs,[],0]
        
for k in result.keys():
    obs=result[k]
    clisosArgs=obs[1]
    for station in obs[0]:
        cmd=clisos+clisosArgs+' -s "%s" -D'%(station,)
        if printSml:
            cmd=clisos+clisosArgs+' -s "%s" -X'%(station,)
        #print cmd
        status,out=commands.getstatusoutput(cmd)
        if status==0:
            if printSml:
                f=open(station+".xml","w")
                f.write(out)
                f.close
            else:
                obs[3]=obs[3]+1
                obs[2].extend(out.split("\n"))
        else:
            print status
            print cmd
            print out
            print out.split("\n")

if not printSml:
    for k in result.keys():   
        print "----------------- %s -----------------"%(k,)
        print "number of stations: ",len(result[k][0])
        print "number of reachable stations: ",result[k][3]
        print "number of params: ",len(result[k][2])
