'''
Created on Sep 17, 2012

@author: sorg
'''

import sys,datetime

def cut(token0):
    tzoffset=datetime.timedelta(hours=int(token0[25]))
    return datetime.datetime.strptime(token0[:23],'%Y-%m-%dT%H:%M:%S.%f')+tzoffset
    #return (timestamp+tzoffset).strftime('%Y-%m-%d %H:%M:%S.%f')
    #return "%s,%s"%((timestamp+tzoffset).strftime('%Y-%m-%d %H:%M:%S.%f'),",".join(tokens[1:]))

if __name__ == '__main__':
    while True:
        row=sys.stdin.readline()
        if row=="":
            break;
        row=row.strip()
        if not row.startswith("#"):
            tokens=row.strip().split(",")   
            token0=tokens[0]
            print "%s,%s"%((cut(token0)).strftime('%Y-%m-%d %H:%M:%S.%f'),",".join(tokens[1:]))
        else:
            print row
        

