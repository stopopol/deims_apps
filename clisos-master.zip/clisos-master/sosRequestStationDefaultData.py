'''
Created on Feb 18, 2015

@author: sorg
'''

def requestData(clisosCmdList):
    pass
