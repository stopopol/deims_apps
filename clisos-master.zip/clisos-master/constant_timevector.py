'''
Created on Jan 7, 2013

@author: sorg
'''

import sys,datetime, getopt

defaultTimestampPattern='%Y-%m-%d %H:%M:%S.%f'

def printUsage():
        print """
   
   usage: python constant_timevector.py OPTIONS
   
   This script produces a constant time vector from the output of clisos by
   filling gaps with a given noData value
   for bug-reports and review send an email to j.sorg@fz-juelich.de
    
   OPTIONS
       --help          print this help
   -h                  constant interval in hours
   -m                  constant interval in minutes
   -n                  no data value (default: -999999999)
   -s                  start time (default: timestamp of first row)
   -t                  timestamp format (python syntax) 
                       default: %Y-%m-%d %H:%M:%S.%f'
                                               
"""

def printUsageAndExit(errorMessage=""):
    """
    print help message to stderr and exit 
    """
    printWarningAndErrors("\n    error:\n    %s"%(errorMessage,))
    printUsage()
    sys.exit()
    
def printWarningAndErrors(message):
    print >> sys.stderr, message

def openInput():
    return sys.stdin
    #testing and debugging
    #return open("/home/sorg/development/fzj/workspace/SosClient/data/input.constant.timevector2")

def getTimeStamp(row):
    tokens=row.split(",")
    return (datetime.datetime.strptime(tokens[0],defaultTimestampPattern),tokens)

def printConstantTimeVector(intervalMinute=0, intervalHour=0, noDataValue=-999999999, startTime=None,):
    # overread header
    stdin=openInput()
    print stdin.readline().strip()
    interval=datetime.timedelta(hours=intervalHour, minutes=intervalMinute)
    one_minute=datetime.timedelta(minutes=1)
    row=stdin.readline().strip()
    timeStamp,tokens=getTimeStamp(row)
    #first row is init for time calculation therefore print it always
    print row
                
    while True:
        expected=timeStamp+interval
        nextRow=stdin.readline().strip()
        if nextRow=="":
            break;
        nextTimeStamp,tokens=getTimeStamp(nextRow)
        while nextTimeStamp - expected >= one_minute:
            print "%s,%s,%s"%(expected.strftime(defaultTimestampPattern),",".join(tokens[1:-1]),noDataValue)
            expected=expected+interval
        print nextRow
        row=nextRow
        timeStamp=nextTimeStamp
        
if __name__ == '__main__':
                    
    try:
        #all possible commandline-arguments
        #see man getopt for detailed description
        opts, args = getopt.getopt(sys.argv[1:], "h:m:n:s:t:", ["help="])
    except getopt.GetoptError, err:
        #if something goes wrong print error message and exit
        printUsageAndExit(str(err))
    hours=0
    minutes=0
    noDataValue=-999999999
    startTime=None
    
    for o, a in opts:
        if o=="--help":
            printUsageAndExit()
        elif o=="-h":
            hours=int(a)
        elif o=="-m":
            minutes=int(a)
        elif o=="-n":
            noDataValue=a
        elif o=="-s":
            startTime=a
        elif o=="-t":
            defaultTimestampPattern=a
            
    # check command line
    if minutes==0 and hours==0:
        printUsageAndExit(errorMessage="at least minutes (-m) or hours (-h) has to be provided")        
    printConstantTimeVector(intervalHour=hours,intervalMinute=minutes,noDataValue=noDataValue,
                            startTime=startTime)
            
            
