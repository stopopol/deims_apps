# clisos
## create minimal tar gzip
```
tar -cf clisos.tar clisos.py org 
gzip clisos.tar 
```   
or use script ./min.tar.sh

## create config file example (all climate (with a K) stations) :
```
python clisos.py -h ibg3wradar.ibg.kfa-juelich.de -p 8080 -u /eifelrur_public_oauth/sos -o Public -S | sort | uniq | grep "_.\*K.\*_" | create.configs.sh "python clisos.py" ibg3wradar.ibg.kfa-juelich.de 8080 /eifelrur_public_oauth/sos Public
```
## replace parameter of each cfg with a new one 
```
find -type f -exec sed -i 's/parameter.*/parameter = AirFlux_CO2_Avg30min_NetExchange/g' {}  \;
```

## mulitple plots writing to file
```
find -type f -exec clisos -f {} -G -l 1 \;
```