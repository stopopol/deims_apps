'''
Created on Jul 12, 2013

@author: sorg
'''
import sys, commands, getopt

def printUsage():
        print """
   
   usage: python sensor_metdata.py OPTIONS
   
   This script downloads sensor descriptions from a sos using clisos.py
   for bug-reports and review send an email to j.sorg@fz-juelich.de
    
   OPTIONS
       --help          print this help
   -i                  file containing sensor names (each name comma separated)
                       if this option is not given, then reads from stdin
   -f                  clisos config file 
       --v             verbose
                                               
"""

def printUsageAndExit(errorMessage=""):
    """
    print help message to stderr and exit 
    """
    printWarningAndErrors("\n    error:\n    %s" % (errorMessage,))
    printUsage()
    sys.exit()
    
def printWarningAndErrors(message):
    print >> sys.stderr, message

def openInput(f=None):
    if f == None:
        return sys.stdin
    return open(f, "r")

try:
    #all possible commandline-arguments
    #see man getopt for detailed description
    opts, args = getopt.getopt(sys.argv[1:], "hf:i:", ["help=","v"])
except getopt.GetoptError, err:
    #if something goes wrong print error message and exit
    printUsageAndExit(str(err))

fn=None
clisos="clisos"
clisosConfig=None
verbose=None
for o, a in opts:
    if o == "--help":
        printUsageAndExit()
    elif o == "-i":
        fn = a
    elif o == "-f":
        clisosConfig = a
    elif o== "--v":
        verbose=1
    
if clisosConfig==None:
    printUsageAndExit("need clisos config file")
f=openInput(fn)
sensors=f.read()
if verbose>0:
    print "will request sensorML for: "+sensors   
for sensor in sensors.strip().split(","):
    cmd=clisos+" -f %s -s %s -X "%(clisosConfig,sensor)
    if verbose>0:
        print "invoking command: ",cmd
    status,output=commands.getstatusoutput(cmd)
    if status!=0:
        print "error: status ",status
        print "output: "+output
    else:
        out=open("%s.xml"%(sensor),"w")
        print "got sensorMl for station ",sensor
        out.write(output)
        out.close()


