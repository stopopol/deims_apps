'''
Created on Oct 12, 2017

@author: sorg
'''

from datetime import datetime,timedelta
import sys,commands

datetimeFormat="%Y-%m-%d"
start=datetime.strptime(sys.argv[1],datetimeFormat)
end=datetime.strptime(sys.argv[2],datetimeFormat)
delta=timedelta(days=int(sys.argv[3]))
cfg=sys.argv[4]
out=sys.argv[5]
pipe=sys.argv[6]


actual=start+delta
while start<end:
    print start.isoformat()," - ",actual.isoformat()
    #fn=start.isoformat()+"__"+actual.isoformat()
    cmd="clisos -e %s,%s -f %s -G %s >> %s"%(start.isoformat(),actual.isoformat(),cfg,pipe,out)
    print cmd
    status,outp=commands.getstatusoutput(cmd)
    if status!=0:
        print outp
    start=actual
    actual=actual+delta
