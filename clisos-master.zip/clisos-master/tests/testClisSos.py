'''
Created on Oct 9, 2012

@author: sorg
'''

fn="/home/sorg/development/fzj/workspace.mars/SearchPortal2/data/ufz/om.ufz.result.xml"
fn="/home/sorg/development/fzj/workspace.mars/SearchPortal2/data/hmgu/getobs.resp.xml"
fn="/home/sorg/development/fzj/tests/clisos/local/agiadata.xml"

from org.fzj.ibg3.sos.client.sos_result_data_format import Sos2Csv

parser=Sos2Csv(open(fn).read())
print parser.formatData(";")



