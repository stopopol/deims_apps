'''
Created on Jul 12, 2013

@author: sorg
'''

import unittest,commands,datetime

defaultTimestampPattern='%Y-%m-%d %H:%M:%S.%f'

class TestCsv2Python(unittest.TestCase):
    
    def testCsv2Python(self):
        cfg="/home/sorg/development/fzj/workspace/SosClient/data/csv2python/terenodata.2.cfg"
        cmd="clisos -f %s -G | python ../cutTimezone.py | python ../csv2python.py"%(cfg,)
        print cmd
        d=datetime.datetime.strptime("2013-07-03 01:40:00.000",defaultTimestampPattern)
        status,out=commands.getstatusoutput(cmd)
        if status!=0:
            print out
        else:
            data=eval(out)
            print data
            print data["ME_EC_001"][d][0]
            print type(data["ME_EC_001"][d][0])
        
