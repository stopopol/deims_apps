'''
Created on Jul 16, 2018

@author: sorg
'''

from owslib.sos import SensorObservationService
from owslib.swe.observation.sos200 import SOSGetObservationResponse
from owslib.etree import etree
#from owslib.swe.observation.sos200.SensorObservationService_2_0_0 import get_observation
#from owslib.swe.common import TimeRange

class Sos:
    def __init__(self,  sos, proxy=None):
        self.service = SensorObservationService("http://"+sos.host+":"+str(sos.port)+sos.url,version='2.0.0')

    def getOfferings(self):
        return self.service.contents
    
    def getObservation(self, getObs, **kwargs):
        return self.service.get_observation(
                        responseFormat=getObs.responseFormat,
                        offerings=getObs.offerings,
                        observedProperties=getObs.observedProperties,
                        eventTime=getObs.eventTime,
                        procedure=getObs.procedure,**kwargs)
        
    def getContent(self):
        print self.service.__dict__.keys()
        print "\n".join(self.service.observed_properties)
        print self.service.contents.keys()
        for off in self.service.contents.keys():
            print type(off)
            print self.service.contents[off]
            print type(self.service.contents[off])
            print self.service.contents[off].__dict__.keys()

        return sorted(self.service.contents)
    
    def getObservedPropertiesFromOffering(self,offeringName):
        return self.service.contents[offeringName].observed_properties
    
    def getStationsFromOffering(self,offeringName):
        return self.service.contents[offeringName].procedures
    
    def getSensorMl(self,procedure, procedureDescriptionFormat="http://www.opengis.net/sensorML/2.0.0"):
        return self.service.describe_sensor(outputFormat=procedureDescriptionFormat, procedure=procedure)
    
from owslib.util import nspath_eval, extract_time, testXMLAttribute, testXMLValue
from owslib.swe.observation.om import nspv, TimePeriod
from owslib.swe.observation.sos200 import ObservationDecoder
from owslib.swe.observation.sos200 import namespaces as ns2
from owslib.swe.observation.sos100 import namespaces as ns1
from datetime import datetime
# from owslib.swe.observation.sos100 import

ns1['om'] = 'http://www.opengis.net/om/1.0'
# ns1['ns'] = 'http://www.opengis.net/swe/1.0.1'
ns2['ns'] = 'http://www.opengis.net/swe/2.0'
ns2['om'] = 'http://www.opengis.net/om/2.0'
ns2['swe'] = 'http://www.opengis.net/swe/2.0'


def nspv1(path):
    return nspath_eval(path, ns1)


def nspv2(path):
    return nspath_eval(path, ns2)


class Measurement:
    def __init__(self, value, uom):
        self.value = float(value)
        self.uom = uom


class Observation:

    def __init__(self, foi, obsprob, proc, phentime, restime, res, flag):
        self.type = "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"
        self.featureOfInterest = foi
        self.observedProperty = obsprob
        self.procedure = proc
        self.phenomenonTime = phentime
        self.resultTime = restime
        self.result = res
        self.flag = flag
        self.id = "_" + str(hash((self.observedProperty, self.procedure, self.resultTime, self.result)))

    def get_result(self):
        """ This will handle different result types using specialised
        observation types """
        return self.result

    def __str__(self):
        return "Type: " + self.type + ", FoI: " + self.featureOfInterest + ", ObsProp: " + self.observedProperty + \
                ", Proc: " + self.procedure + ", resTime: " + self.resultTime.isoformat() + ", result: " \
               + str(self.get_result().value) + ", Flag: " + self.flag


class SOSResponseV1:
    def __init__(self, element, MOIDA):
        self.observations = []
        if MOIDA:
            obs_data = element.findall(nspath_eval("om:member/om:Observation", ns1))
            if len(obs_data)>0:
                self.observations = self.decode_array(obs_data[0])
        else:
            obs_data = element.findall(nspath_eval("om:member/om:Measurement", ns1))
            for obs in obs_data:
                self.observations.append(self.decode_single(obs))

    def decode_array(self, element):
        foi = testXMLAttribute(element.find(
            nspv1("om:featureOfInterest/gml:FeatureCollection/gml:featureMember/sa:SamplingPoint")), nspv1("gml:id"))
        obsprob = testXMLAttribute(element.find(nspv1(
            "om:result/swe:DataArray/swe:elementType/swe:SimpleDataRecord/swe:field/swe:Quantity")), "definition")
        proc = testXMLAttribute(element.find(nspv1(
            "om:procedure")), nspv1("xlink:href"))
        uom = testXMLAttribute(element.find(
            nspv1("om:result/swe:DataArray/swe:elementType/swe:SimpleDataRecord/swe:field/swe:Quantity/swe:uom")),
            "code")
        values = element.find(nspv1("om:result/swe:DataArray/swe:values")).text
        values = values.split(";")
        observations = []
        for value in values:
            params = value.split(",")
            if len(params) > 2:
                time = datetime.strptime(params[0], "%Y-%m-%dT%H:%M:%S.%f%z")
                observations.append(Observation(foi, obsprob, proc, time, time, Measurement(params[2], uom), params[3]))
        return observations

    def decode_single(self, element):
        foi = testXMLAttribute(element.find(nspv1(
            "om:featureOfInterest/sa:SamplingPoint")), nspv1("gml:id"))
        obsprob = testXMLAttribute(element.find(nspv1(
            "om:observedProperty")), nspv1("xlink:href"))
        proc = testXMLAttribute(element.find(nspv1(
            "om:procedure")), nspv1("xlink:href"))
        phentime = extract_time(element.find(nspv1("om:samplingTime/gml:TimeInstant/gml:timePosition")))
        restime = phentime
        res = Measurement(element.find(nspv1("om:result")).text,
                          testXMLAttribute(element.find(nspv1("om:result")), "uom"))
        flag = element.find(nspv1("om:resultQuality/swe:Text/swe:value")).text
        return Observation(foi, obsprob, proc, phentime, restime, res, flag)


class SOSResponseV2:
    def __init__(self, element, MOIDA=False):
        obs_data = element.findall(
            nspath_eval("sos:observationData/om20:OM_Observation", ns2))
        self.observations = []
        if MOIDA:
            if len(obs_data)>0:
                self.observations = self.decode_array(obs_data[0])
        else:
            self.decoder = ObservationDecoder()
            for obs in obs_data:
                self.observations.append(self.decode_single(obs))
            # self.observations.append(parsed_obs)

    def decode_array(self, element):
        foi = testXMLAttribute(element.find(nspv2(
            "om20:featureOfInterest")), nspv2("xlink:href"))
        obsprob = testXMLAttribute(element.find(nspv2(
            "om20:observedProperty")), nspv2("xlink:href"))
        proc = testXMLAttribute(element.find(nspv2(
            "om20:procedure")), nspv2("xlink:href"))
        uom = testXMLAttribute(element.find(
            nspv2("om:result/ns:DataArray/ns:elementType/swe:DataRecord/ns:field/swe:Quantity/ns:uom")), "code")
        values = element.find(nspv2("om:result/ns:DataArray/ns:values")).text
        values = values.split(";")
        observations = []
        for value in values:
            params = value.split(",")
            time = datetime.strptime(params[0], "%Y-%m-%dT%H:%M:%S.%fZ")
            observations.append(Observation(foi, obsprob, proc, time, time, Measurement(params[1], uom), params[2]))
        return observations

    def decode_single(self, element):
        parsed_obs = self.decoder.decode_observation(element)
        if parsed_obs.phenomenonTime is TimePeriod:
            phenomenonTime = parsed_obs.phenomenonTime.end
        else:
            phenomenonTime = parsed_obs.phenomenonTime
        if parsed_obs.resultTime:
            resultTime = parsed_obs.resultTime
        else:
            resultTime = parsed_obs.phenomenonTime
        flag = element.find(nspv2("om20:parameter/om20:NamedValue/om20:value")).text
        return Observation(parsed_obs.featureOfInterest, parsed_obs.observedProperty, parsed_obs.procedure,
                           phenomenonTime, resultTime, parsed_obs.get_result(), flag)

         
sos=Sos("ibg3wradar.ibg.kfa-juelich.de",8080,"/sample.public.sos2/service")
print sos.getObservedPropertiesFromOffering("WU_AW_014")
print sos.getOfferings()
print sos.getStationsFromOffering("WU_AW_014")
print sos.getSensorMl("WU_AW_014")
print sos.getSensorMl("WU_AW_014", procedureDescriptionFormat="http://www.opengis.net/sensorML/1.0.1")
getObsResp= sos.getObservation("http://www.opengis.net/om/2.0", ["WU_AW_014",], ['StreamWaterSmpConcentrationDOC',], procedure="WU_AW_014")
getObsResp= sos.getObservation("http://www.opengis.net/om/2.0", ["WU_AW_014",], ['StreamWaterSmpConcentrationDOC',], procedure="WU_AW_014", MergeObservationsIntoDataArray=True)
parsedOm=SOSGetObservationResponse(etree.fromstring(getObsResp))
ts=parsedOm.observations[0]
print type(ts)
res=ts.get_result()
print type(res)
print res.__dict__.keys()
print res

ts=parsedOm.observations[1]
print type(ts)
res=ts.get_result()
print type(res)
print res.__dict__.keys()
print res

# for offContent in sos.getContent():
#     print type(offContent)
#     print type(offContent.keys())