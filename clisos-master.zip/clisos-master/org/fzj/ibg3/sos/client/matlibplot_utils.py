import datetime
import io
try:
    import matplotlib.dates as mdates
    import matplotlib.pyplot as plt
except:
    pass
try:
    import numpy as np
except:
    pass

try:
    dpi = plt.rcParams['figure.dpi']
except:
    dpi = 1

def __plotData(data,fmt,toout):
    plottingDataAll={}
    defaultTimestampPattern='%Y-%m-%dT%H:%M:%S.%f'
    # pk=(TimeStamp,StationId)
    pks=list(data.keys())
    pks.sort()
    #print pks
    if fmt!=None:
            fmt=fmt.split(',')
    else:
        fmt=['b-','g-','r-','c-','m-','y-','k-','w-']
    lenFmt=len(fmt)
    lenEx=0
    oks=0
    params={}
    for pk in pks:
        station=pk[1]
        row=data[pk]
        for field in list(row.keys()):
            params[field]=field
        plottingDataAll[station]={"time":[]}
    
        
    for pk in pks:
        plottingData=plottingDataAll[pk[1]]
        try:
            t=datetime.datetime.strptime(pk[0][0:-6],defaultTimestampPattern)
        except: 
                #import pdb
                #pdb.set_trace()
            print("exception pk: ",pk)
        plottingData["time"].append(mdates.date2num(t))
        row=data[pk]
        for field in list(params.keys()):
            if not field.endswith("QualityFlag"):
                v=np.nan
                vstr=row[field]
                if field in row:
                    if vstr=="noData":
                      v=np.nan
                    else:
                      v=np.float(vstr)
                if field in plottingData:
                    plottingData[field].append(v)
                else:
                    plottingData[field]=[v]     
    i=0
    fix,ax = plt.subplots(figsize=(2000/dpi,1000/dpi))
    for station in list(plottingDataAll.keys()):
        plottingData=plottingDataAll[station]
#        print (len(plottingData["time"]))
        if len(plottingData["time"])>0:
            ylabel=""
            for param in list(plottingData.keys()):
                if param!="time":
                    ylabel=param
                    c=fmt[i%lenFmt]
                    ax.plot_date(plottingData["time"], plottingData[param],fmt=c)
                    i=i+1
            ax.set_xlabel('time (s)')
            ax.set_ylabel(ylabel)
            ax.set_title(station)
            #plt.show()
            toout("%s_%s"%(station,"_".join(filter(lambda x: x!="time",list(plottingData.keys())))))
#    print ("number of exceptions: ",lenEx)
#    print ("number of ok: ",oks)
        
        

    
def streamPlotData(data,imageFormat,fmt=None):
    __plotData(data,fmt)
    sio = io.StringIO()
    plt.savefig(sio, format=imageFormat)
    return sio

def displayPlotData(data, fmt=None):
    __plotData(data,fmt,lambda x: plt.show())
    
def savePlot(data, fmt=None):
    __plotData(data,fmt,lambda x: plt.savefig("%s.png"%(x,), format="png"))

    #plt.show()

