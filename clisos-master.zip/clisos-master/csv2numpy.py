'''
Created on Jul 12, 2013

@author: sorg
'''

import sys, getopt, datetime
from numpy import array

defaultTimestampPattern='%Y-%m-%d %H:%M:%S.%f'

def printUsage():
        print """
   
   usage: python csv2python.py OPTIONS
   
   This script converts csv files (maybe downloaded sensor data with clisos)
   into python data structures.
   for bug-reports and review send an email to j.sorg@fz-juelich.de
    
   OPTIONS
       --help          print this help
   -f                  file containing csv formatted data. 
                       if this option is not given, then reads from stdin
       --v             verbose
                                               
"""

def printUsageAndExit(errorMessage=""):
    """
    print help message to stderr and exit 
    """
    printWarningAndErrors("\n    error:\n    %s" % (errorMessage,))
    printUsage()
    sys.exit()
    
def printWarningAndErrors(message):
    print >> sys.stderr, message

def openInput(f=None):
    if f == None:
        return sys.stdin
    return open(f, "r")

try:
    #all possible commandline-arguments
    #see man getopt for detailed description
    opts, args = getopt.getopt(sys.argv[1:], "hf:", ["help=","v"])
except getopt.GetoptError, err:
    #if something goes wrong print error message and exit
    printUsageAndExit(str(err))

fn=None
verbose=None
for o, a in opts:
    if o == "--help":
        printUsageAndExit()
    elif o == "-f":
        fn = a
    
f=openInput(fn)

header=f.readline()

i=header.find("#")
if i>0:
    header=header[i:]
fields=[field.strip() for field in header.split(",")]
stationData={}
data={}
station=""
for row in f:
    values=row.strip().split(",")
    newRow=[]
    for v in values[2:]:
        try:
            newRow.append(float(v))
        except:
            newRow.append(str(v))
    stationData[datetime.datetime.strptime(values[0],defaultTimestampPattern)]=newRow
    #stationData[datetime.datetime.strptime(values[0],defaultTimestampPattern)]=[float(v) for v in values[2:] ]
    if station!=values[1]:
        station=values[1]
        data[station]=stationData
        
print data
       
 
