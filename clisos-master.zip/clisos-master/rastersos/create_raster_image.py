#!/usr/bin/python
'''
Created on Nov 7, 2017

@author: sorg
'''
from PIL import Image
import sys,math,traceback, getopt
from intervaltree import Interval, IntervalTree

def printUsage():
    print """
    usage: python create_raster_image.py -w WIDTH_IN_PIXEL -h HEIGHT_IN_PIXEL -c COLORTABLE_FILENAME -o OUTDIR -f [INPUT] [-v] [-s] [-r]
           OPTIONS:
              -w WIDTH_IN_PIXEL          Image width in pixels 
              -h HEIGHT_IN_PIXEL         Image height in pixels
              -c COLORTABLE_FILENAME     a color table used to create the image. File content is python code 
                                         which can be executed and initialized with python's buildin eval-
                                         function. The code must generate a IntervalTree object.                                  
                                         e.g.  IntervalTree([Interval(-64.0, -63.2440944882, (0, 0, 0, 0)),...
                                         a example file with color table used with the weather radar 
                                         sophienhoehe can be found in clisos program directory and is called
                                         colortable.python.eval
              -o OUTDIR                  generated images will be stored in this directory
              -f INPUT                   is optional! if omitted then data is read from stdin
              -v                         be verbose
              -s                         show image in a popup window
              -r                         extract bounding box with not null pixels, create a new image with
                                         this bounds and scale it to the original size (-w,-h)
"""

def printUsageAndExit(exitCode=-1):
    printUsage()
    if exitCode!=0:
        traceback.print_exc(file=sys.stderr)
    sys.exit(exitCode)
    
def getCoord(pixelIdx,w):
    x=math.fmod(pixelIdx,w)
    y=(int)(pixelIdx/w)
    return (int(x),y)

def getScaledImage(im):
    left,upper,right,lower=im.getbbox()
    new_w=right-left
    new_h=lower-upper
    scaleFac=(int)(min(h/new_h,w/new_w))
    scaledImage=im.crop(im.getbbox())
    return scaledImage.resize((scaledImage.size[0]*scaleFac,scaledImage.size[1]*scaleFac))

def saveOrShow(show,resize,im,fn):
    if resize:
        im=getScaledImage(im)
    if show:
        im.show()
    im.save(fn)
    
def iterateOverInput(f, writeOut, show, resize, colorTableFile,w,h,result=None, verbose=False):
    im = None
    fn=""
    ff=open(colorTableFile,"r")
    colorTableIntervalTree=eval(ff.read())
    ff.close()
    while True:
        line=f.readline()
        if line==None or line=="":
            if verbose:
                print "save to ",fn
            if writeOut:
                saveOrShow(show, resize, im, fn)
            break
        if line.startswith("#"):
            if im!=None:
                if verbose:
                    print "save to ",fn
                if writeOut:
                    saveOrShow(show, resize, im, fn)
            im = Image.new("RGBA", (w, h))
            if result!=None:
                result.append(im)
            #timestamp: 2017-04-01T10:10:00.000+02:00;
            if writeOut:
                fn=outputDir+"/"+line[12:41].replace(":","_").replace("+","_")+".png"
        else:
            t=line.split(",")
            rgba=list(colorTableIntervalTree[float(t[1])])[0].data
            x,y=getCoord(int(t[0]),w)
            im.putpixel((x,y),rgba)

if __name__ == "__main__":
    try:
        opts, args = getopt.getopt(sys.argv[1:], "h:w:c:o:f:svr", ["help="])
    except getopt.GetoptError, err:
        printUsageAndExit(str(err))
        
    h=None
    w=None
    colortableFn=None
    outputDir=None
    f=None
    verbose=False
    show=False
    inputFile=None
    resize=False
    for o, a in opts:
        if o == "--help":
            printUsage()
        elif o == "-h":
            h = int(a)
        elif o == "-w":
            w = int(a)
        elif o == "-c":
            colortableFn = a
        elif o == "-o":
            outputDir = a
        elif o == "-s":
            show = True
        elif o == "-f":
            inputFile = a
        elif o == "-v":
            verbose = True
        elif o == "-r":
            resize = True
    
    if inputFile!=None:
        f=open(inputFile,"r")
    else:
        f=sys.stdin
    
    im = None
    fn=""
    iterateOverInput(f, True, show, resize, colortableFn)
#    while True:
#        line=f.readline()
#        if line==None or line=="":
#            if verbose:
#                print "save to ",fn
#            saveOrShow(show, resize, im, fn)
#            break
#        if line.startswith("#"):
#            if im!=None:
#                if verbose:
#                    print "save to ",fn
#                saveOrShow(show, resize, im, fn)
#            im = Image.new("RGBA", (w, h))
#            #timestamp: 2017-04-01T10:10:00.000+02:00;
#            fn=outputDir+"/"+line[12:41].replace(":","_").replace("+","_")+".png"
#        else:
#            t=line.split(",")
#            rgba=list(colorTableIntervalTree[float(t[1])])[0].data
#            x,y=getCoord(int(t[0]))
#            im.putpixel((x,y),rgba)
            
