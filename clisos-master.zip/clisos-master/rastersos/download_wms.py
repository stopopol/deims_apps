'''
Created on Oct 9, 2017

@author: sorg
'''
import sys, getopt, commands
from urlparse   import parse_qs, urlparse, urlunparse
from urllib import urlencode

def printUsage():
        print """
   
   usage: python download_wms.py OPTIONS
   
   This script downloads images from a ogc wms service. as input it expects a list of wms GetMap urls.
   for bug-reports and review send an email to j.sorg@fz-juelich.de
   
   -h                  print this help
   -u                  download images - default: only print download URL
   -w WIDTH            desired width in pixels
   -j HEIGHT           desired height in pixels
   -t IMAGE_TYPE       desired image type ("image/png", "image/jpeg", "image/geotiff",...)
   -f FILE             use file instead of stdin
   -b BBOX             specify a bounding box filter: MinX,MinY,MaxX,MaxY
   -d OUTPUT_DIR       downloads going into this folder (without tailing slash)
                                                  
"""

def printUsageAndExit(errorMessage=""):
    """
    print help message to stderr and exit 
    """
    printWarningAndErrors("\n    error:\n    %s"%(errorMessage,))
    printUsage()
    sys.exit()
    
def printWarningAndErrors(message):
    print >> sys.stderr, message

def setWidthAndHeight(w,h,qs):
    if w!=None:
        qs["width"]=w
    if h!=None:
        qs["height"]=h
        
def setImageType(t,qs):
    if t!=None:
        qs["format"]=t
        
def setBbox(b,qs):
    if b!=None:
        qs["bbox"]=b
        
def downloadTo(outDir,url,fn):
    if outDir==None:
        outDir="."
    cmd='curl "%s" > "%s/%s"'%(url,outDir,fn.strip())
    if verbose:
        print "download command: ", cmd
    status,out=commands.getstatusoutput(cmd)
    if status != 0:
        print "error while exec command: ",cmd
        print out
        
def getFileName(qs,imgType):
    """
    works not for all image types
    """
    if imgType==None:
        imgType=qs["format"][0]
    if verbose:
        print "image type: ",imgType
    fn=qs["layers"][0].replace(":", "-")+"."+imgType[imgType.index("/")+1:]
    if verbose:
        print "filename: "+fn
    return fn
   
try:
    opts, args = getopt.getopt(sys.argv[1:], "hvuw:j:f:t:d:b:",
                               [])
except getopt.GetoptError, err:
    printUsageAndExit(str(err))

width=None
height=None
imageType=None
outDir=None
bbox=None
verbose=False
doNotDownload=True
inp=sys.stdin
for o, a in opts:
    if o == "-h":
        printUsage()
        exit(0)
    elif o == "-w":
        width=a
    elif o == "-j":
        height=a
    elif o == "-t":
        imageType=a
    elif o == "-d":
        outDir=a
    elif o == "-b":
        bbox=a
    elif o == "-v":
        verbose=True
    elif o == "-u":
        doNotDownload=False
    elif o == "-f":
        inp=open(a,"r")

for line in inp:
    
    print "processing input: ",line
    parsed_url = urlparse(line)
    qs=parse_qs(parsed_url.query)
    
    setWidthAndHeight(width, height, qs)
    setImageType(imageType, qs)
    setBbox(bbox, qs)
    
    new_url_parts = list(parsed_url)
    new_url_parts[4] = urlencode(qs,doseq=True)
    new_url= urlunparse(new_url_parts)
    
    print new_url
    if not doNotDownload:
        fn=getFileName(qs, imageType)
        downloadTo(outDir, new_url, fn)
    
    
