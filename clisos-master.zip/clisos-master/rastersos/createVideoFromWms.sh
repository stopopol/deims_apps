#!/bin/bash

#Created on Jun 3, 2019
#@author: sorg

clisos -f ibg3wradar.raster.out-of-band.cfg -G | python download_wms.py -w 800 -j 400 -u &&
for f in $(find -type f -name "*.png" -size +1k); do convert -pointsize 40 -fill black -font "DejaVu-Sans-Mono" -undercolor white -draw "text 5,350 \"${f:47:10}\" " $f $f; done
find -type f -name "*.png" -size +1k | sort | xargs cat | ffmpeg -f image2pipe -r 20 -i - -vcodec libx264 wu.swc.20cm.mp4

