'''
Created on Oct 12, 2017

@author: sorg
'''

import sys

if len(sys.argv)>2:
    f=open(sys.argv[2])
else:
    f=sys.stdin
threshold= float(sys.argv[1])
line_buffer=[]
while True:
    line=f.readline()
    if line==None or len(line)<=0:
        break
    line=line.strip()
    if line.startswith("#"):
        if len(line_buffer)>1:
            print "\n".join(line_buffer)
        line_buffer=[line]
    else:
        tokens=line.split(",")
        if len(tokens)>1:
            v=float(tokens[1])
            if v>threshold:
                line_buffer.append(line)
                
                