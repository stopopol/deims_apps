'''
Created on Nov 17, 2017

@author: sorg
'''

from create_raster_image import iterateOverInput
from sys import stdin
from PIL import Image

res=[]
# 2432120.92429259 x
# 5543664.72904549 y
#bbox: 5543664.72904549,2432120.92429259,5743664.72904549,2632120.92429259;srs: urn:ogc:def:crs:EPSG::31466;resolution: 800,800
bbox=(5543664.72904549,2432120.92429259,5743664.72904549,2632120.92429259)
h=800
w=800
geo_w=bbox[2]-bbox[0]
geo_pixel_w_h=geo_w/w
print "geo width of pixel: ",geo_pixel_w_h
#-h 800 -w 800 -c colortable.python.eval -o data -f /home/sorg/Documents/heye/test.txt -s -r
f=open("/home/sorg/Documents/heye/test.txt","r")
f=open("/home/sorg/Documents/heye/shapes.marvin/out.verschoben","r")
f=stdin
iterateOverInput(f, False, False, False, "/home/sorg/development/fzj/workspace/SosClient/colortable.python.eval",800,800, res)
for im in res:
    pp=[]
    w,h=im.size
    for y in range(0,h):
        for x in range(0,w):
            v=im.getpixel((x,y))
            if v!=(0,0,0,0):
                geo_x=x*geo_pixel_w_h+bbox[1]+geo_pixel_w_h
                geo_y=bbox[2]-(y*geo_pixel_w_h)-geo_pixel_w_h
                pp.append("("+str(geo_x)+" "+str(geo_y)+")")
    print "Multipoint(",",".join(pp),")"
