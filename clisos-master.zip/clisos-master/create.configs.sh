#!/bin/bash

clisos=$1
host=$2
port=$3
url=$4
offering=$5


CONFIG_TEMPLATE="
[getObservation]
offering = $offering
stations = STATIONS_
parameter = PARAMETERS
resultmodel = om:Observation
starttime = 2020-09-14T15:45:19
endtime = 2020-09-15T15:45:19

[connection]
host = $host
port = $port
url  = $url

"

while read proc;
do
    echo "create config: $proc"
    b=$(echo $($clisos -h $host -p $port -u $url -s $proc -D))
    b="${b// /,}"
    v="${CONFIG_TEMPLATE/PARAMETERS/$b}"
    c="${v/STATIONS_/$proc}"
    echo "$c" > $proc.cfg
done
