'''
Created on Feb 13, 2015

@author: sorg
'''

def callClisos(fn):
    f=open(fn,"r")
    result={}
    for line in f:
        if line[0]=='#':
            continue
        t=line.split(" ")
        port=80
        host=t[1]
        host=host.replace("http://","")
        t2=host.split(":")
        if len(t2)>1:
            host=t2[0]
            port=t2[1]
        name=t[0]
        url=t[2].strip()
        #print "\nname: %s\nhost: %s\nport: %s\nurl: %s\n"%(name,host,port,url)
        result[name]=" -h %s -p %s -u %s"%(host,port,url)
    return result



if __name__ == "__main__":   
    import sys
    res=callClisos(sys.argv[1])
    for k in res.keys():
        print res[k]

        
