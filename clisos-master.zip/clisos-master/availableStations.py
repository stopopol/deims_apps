'''
Created on Mar 17, 2015

@author: sorg
'''

import commands,sys


def printCmd(cmd,p=False):
    if p:
        print cmd
    
c=sys.argv[1]
sos=sys.argv[2]
if len(sys.argv)>3:
    pythonStructure=sys.argv[3]
else:
    pythonStructure=None

clisos="%s %s"%(c,sos)

cmd="%s -O"%(clisos)
printCmd(cmd)
status,out=commands.getstatusoutput(cmd)
#allParams=[]
allStations={}
if status==0:
    offerings=out.split("\n")
    for offering in offerings:
        cmd='%s -o "%s" -S'%(clisos,offering)
        printCmd(cmd)
        status,out=commands.getstatusoutput(cmd)
        if status==0:
            stations=out.split("\n")
            for station in stations:
                cmd='%s -s "%s" -D'%(clisos,station)
                printCmd(cmd)
                status,out=commands.getstatusoutput(cmd)
                if status==0:
                    params=out.split("\n")
                    if allStations.has_key(station):
                        allStations[station]=allStations[station]+params
                    else:
                        allStations[station]=params
                else:
                    printCmd(cmd,True)
        else:
            printCmd(cmd,True)
else:
    printCmd(cmd,True)
if pythonStructure!=None:
    printCmd(allStations,True)
else:
    np=0
    for k in allStations:
        stations=allStations[k]
        print k
        for s in stations:
            print "   ",s
            np=np+1
    print "number of stations: ",len(allStations)
    print "number of params:   ",np
    
    
    

            

