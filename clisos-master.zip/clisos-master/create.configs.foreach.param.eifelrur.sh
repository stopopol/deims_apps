#!/bin/bash

clisos=clisos
host=ibg3wradar.ibg.kfa-juelich.de
port=8080
url=/eifelrur_public/sos
offering=Public

bash create.configs.foreach.param.sh $clisos $host $port $url $offering <&0

