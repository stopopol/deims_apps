#!/bin/sh

tar -cf clisos.tar clisos.py org 
gzip clisos.tar 